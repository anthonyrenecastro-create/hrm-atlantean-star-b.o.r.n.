import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { HRMEngine } from "./src/lib/hrm-engine.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
    },
  });

  const hrm = new HRMEngine();

  app.use(express.json());

  // API Routes
  app.get("/api/hrm/state", (req, res) => {
    res.json(hrm.getState());
  });

  app.post("/api/hrm/perturb", (req, res) => {
    const { perturbation } = req.body;
    const newState = hrm.evolve(perturbation);
    io.emit("hrm:update", newState);
    res.json(newState);
  });

  app.post("/api/hrm/traits", (req, res) => {
    const { traits } = req.body;
    hrm.updateTraits(traits);
    const newState = hrm.getState();
    io.emit("hrm:update", newState);
    res.json(newState);
  });

  // Socket.io for real-time simulation
  io.on("connection", (socket) => {
    console.log("Client connected to HRM simulation");
    socket.emit("hrm:update", hrm.getState());

    socket.on("hrm:sync", () => {
      socket.emit("hrm:update", hrm.getState());
    });
  });

  // Continuous simulation loop (background)
  setInterval(() => {
    const newState = hrm.evolve();
    io.emit("hrm:update", newState);
  }, 1000);

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const PORT = 3000;
  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
